package filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

public class EncodingFilter implements Filter {

	String encodingName;
	String requestMethod;

	public void init(FilterConfig fConfig) throws ServletException{
		System.out.println("EncodingFilter init start");
		encodingName = fConfig.getInitParameter("encode");
		requestMethod = fConfig.getInitParameter("method");
		System.out.println("EncodingFilter init end");
	}
	
	
	@Override
	public void doFilter(ServletRequest rq, ServletResponse rp, FilterChain ch)
			throws IOException, ServletException {
		System.out.println("EncodingFilter doFilter start");
		HttpServletRequest req = (HttpServletRequest)rq;
		
		String method = req.getMethod();
		System.out.println("doFilter req.getMethod() = " + method);
		if(method.equals(requestMethod)) {
			rq.setCharacterEncoding(encodingName);
			String rqEncoding = rq.getCharacterEncoding();
			System.out.println("rq.setCharacterEncoding(encodingName); = "+ rqEncoding);
		}
		rp.setContentType("text/html; charset=utf-8");
		ch.doFilter(rq,rp);
		System.out.println("EncodingFilter doFilter end");
		
	}

}
