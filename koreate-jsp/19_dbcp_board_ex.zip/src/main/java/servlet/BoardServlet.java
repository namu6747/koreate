package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import test.BoardFactory;

public class BoardServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Servlet GET = " + req);
		System.out.println("Servlet GET = " + resp);
//		System.out.println("req.getParameter(\"boardTitle\") = " + req.getParameter("boardTitle"));

		String RequestURI = req.getRequestURI();
		String contextPath = req.getContextPath();
		String command = RequestURI.substring(contextPath.length());

		System.out.println("RequestURI = " + RequestURI);
		System.out.println("contextPath = " + contextPath);
		System.out.println("command = " + command);

		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		BoardFactory fac = new BoardFactory();

		System.out.println("Servlet POST request = " + req);
		System.out.println("Servlet POST response = " + resp);
//		System.out.println("req.getParameter(\"boardTitle\") = " + req.getParameter("boardTitle"));

		String RequestURI = req.getRequestURI();
		String contextPath = req.getContextPath();
		String command = RequestURI.substring(contextPath.length());

		System.out.println("RequestURI = " + RequestURI);
		System.out.println("contextPath = " + contextPath);
		System.out.println("command = " + command);

		if (command.equals("/ddd")) {
			RequestDispatcher rd = req.getRequestDispatcher("index.jsp");
			rd.forward(req, resp);
		} else if (command.equals("/")) {
			RequestDispatcher rd = req.getRequestDispatcher("board/board_list_page.jsp");
			rd.forward(req, resp);
		}
		
		System.out.println("========================");

	}

}
