package test;

import java.util.List;

import service.PostService;
import util.PageMaker;
import vo.BoardVO;


public class DaoTest {

	public static void main(String[] args) {

		BoardFactory fac = new BoardFactory();
		PostService ps = fac.createPostService();
		PageMaker pm = fac.createPageMaker();
		BoardVO post1 = new BoardVO();
		post1.setBoardTitle("title1");
		post1.setBoardAuth("auth1");
		post1.setBoardContent("content1");
		
		System.out.println("post1 = " + post1);
		System.out.println(post1.hashCode());
		
		BoardVO post3 = new BoardVO();
		post3.setBoardTitle("title1");
		post3.setBoardAuth("auth1");
		post3.setBoardContent("content1");
		
		System.out.println("post3 = " + post3);
		System.out.println(post3.hashCode());
		
		
		BoardVO post2 = new BoardVO();
		post2.setBoardTitle("title2");
		post1.setBoardAuth("auth2");
		post1.setBoardContent("content2");
		
		System.out.println("post2 = " + post2);
		System.out.println(post2.hashCode());
		
		ps.write(post1);
		List<BoardVO> list = ps.temp();
		if(list.contains(post1)) {
			int index = list.indexOf(post1);
			post1 = list.get(index);
		}
		
		// 재정의한 hashcode를 비교하지 않음
		System.out.println("test post1 == post3 = " + (post1 == post3));
		
		String msgEdit = ps.edit(post1, post2);
		String msgDelete = ps.delete(post1);
		list = ps.getPostAll(pm);
		System.out.println(list);
		
		System.out.println("msgEdit = " + msgEdit);
		System.out.println("msgDelete = " + msgDelete);
	}

}
