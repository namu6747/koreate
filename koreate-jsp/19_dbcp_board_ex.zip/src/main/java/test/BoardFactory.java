package test;
import repository.JdbcPostRepository;
import repository.PostRepository;
import service.PostService;
import service.PostServiceImpl;
import util.PageMaker;

public class BoardFactory {

	private PostRepository createPostRepository() {
		return new JdbcPostRepository();
	}
	
	public PostService createPostService() {
		return new PostServiceImpl(createPostRepository());
	}
	
	public PageMaker createPageMaker() {
		return new PageMaker();
	}
	
}
