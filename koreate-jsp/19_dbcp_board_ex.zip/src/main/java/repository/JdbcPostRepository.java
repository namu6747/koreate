package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import util.DBCPUtil;
import util.PageMaker;
import vo.BoardVO;

public class JdbcPostRepository implements PostRepository {

	/*
	 * try{ int boardNum = Integer.parseInt(num); String sql =
	 * "SELECT boardTitle, boardAuth, boardContent "
	 * +" FROM tblBoard WHERE boardNum = ? "; pstmt = conn.prepareStatement(sql);
	 * pstmt.setInt(1, boardNum); rs = pstmt.executeQuery(); if(rs.next()){ title =
	 * rs.getString(1); auth = rs.getString(2); content = rs.getString(3); }
	 * DBCPUtil.close(rs,pstmt);
	 * 
	 * sql = "UPDATE tblBoard SET " +"	boardReadCount = boardReadCount + 1"
	 * +" WHERE boardNum = ? "; pstmt = conn.prepareStatement(sql); pstmt.setInt(1,
	 * boardNum); pstmt.executeUpdate(); }catch(Exception e){ e.printStackTrace();
	 * }finally{ DBCPUtil.close(rs,pstmt,conn); }
	 */
	
	

	
	@Override
	public Optional<BoardVO> findByNum(int num) {
		System.out.println("findbyNum");
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		int boardNum = num;
		BoardVO vo = null;

		try {
			String sql = "SELECT boardTitle, boardAuth, boardContent " + "FROM tblBoard WHERE boardNum = ? ";
			conn = DBCPUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, boardNum);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				vo = new BoardVO();
				String title = rs.getString("boardTitle");
				String auth = rs.getString("boardAuth");
				String content = rs.getString("boardContent");

				vo.setBoardTitle(title);
				vo.setBoardAuth(auth);
				vo.setBoardContent(content);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return Optional.ofNullable(vo);
	}

	@Override
	public List<BoardVO> tempFindAll() {
		List<BoardVO> list = new ArrayList<>();
		Connection conn = DBCPUtil.getConnection();
		String sql = "SELECT * FROM tblboard";
		ResultSet rs = null;
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				BoardVO vo = new BoardVO(
						rs.getInt(1),
						rs.getString(2),
						rs.getString(3),
						rs.getString(4),
						rs.getInt(5),
						rs.getTimestamp(6)
					);
					list.add(vo);
			}
			System.out.println("tempFindAll complete");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("tempFindAll failed");
		}
		
		return list;
	}

	@Override
	public String update(BoardVO beforePost, BoardVO afterPost) {
		System.out.println("update");
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String msg = "";
		
		try {
			String sql = "UPDATE tblBoard SET " + " boardTitle = ? ," + " boardAuth = ? ," + " boardContent = ? "
					+ " WHERE boardNum = ? ";
			conn = DBCPUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, afterPost.getBoardTitle());
			pstmt.setString(2, afterPost.getBoardAuth());
			pstmt.setString(3, afterPost.getBoardContent());
			pstmt.setInt(4, beforePost.getBoardNum());

			int result = pstmt.executeUpdate();
			System.out.println("update result : "+ result);
			if (result > 0) {
				msg = "수정 완료";
			} else {
				msg = "수정 실패";
			}
		} catch (Exception e) {
			e.printStackTrace();
			msg = "수정 실패";
		} finally {
			DBCPUtil.close(pstmt, conn);
		}

		return msg;
	}

	@Override
	public int countRow() {
		System.out.println("countRow");
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		int result = 0;
		try {
			String sql = "SELECT count(*) FROM tblBoard";
			conn = DBCPUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				rs.getInt(1);
			}
		} catch (

		Exception e) {
			e.printStackTrace();
		} finally {
			DBCPUtil.close(rs, pstmt, conn);
		}

		return result;
	}

	@Override
	public String delete(BoardVO vo) {
		System.out.println("delete");
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String msg = "";

		try {
			String sql = "DELETE FROM tblBoard " + " WHERE boardNum = " + vo.getBoardNum();
			conn = DBCPUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			int result = pstmt.executeUpdate();
			
			System.out.println("delete result : "+ result);
			msg = (result > 0) ? "삭제 완료" : "삭제 실패";
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBCPUtil.close(pstmt, conn);
		}

		return msg;
	}

	@Override
	public List<BoardVO> sortedFindAll(PageMaker pm) {
		System.out.println("sortedFindAll");
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		List<BoardVO> list = new ArrayList<>();

		try {
			String sql = "SELECT * FROM tblBoard " + " ORDER BY boardNum DESC limit ?, ?";
			conn = DBCPUtil.getConnection();
			
			int currentPage = 0;
			int startRow = 0;
			int pageCount = 0;
			
			startRow = (currentPage - 1) * pageCount;
			pstmt = conn.prepareStatement(sql);
			 pstmt.setInt(1, startRow);
			 pstmt.setInt(2, pageCount);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				BoardVO vo = new BoardVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),
						rs.getTimestamp(6));
				list.add(vo);
			}

			DBCPUtil.close(rs, pstmt);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBCPUtil.close(rs, pstmt, conn);
		}
		return list;
	}

	@Override
	public String insert(BoardVO vo) {
		System.out.println("insert");
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String msg = "";

		try {
			String sql = "INSERT INTO tblBoard" + " VALUES(null,?,?,?,0,now())";
			conn = DBCPUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getBoardTitle());
			pstmt.setString(2, vo.getBoardAuth());
			pstmt.setString(3, vo.getBoardContent());

			int result = pstmt.executeUpdate();
			if (result > 0) {
				msg = "게시글 작성 완료";
			} else {
				msg = "게시글 작성 실패";
			}
		} catch (Exception e) {
			e.printStackTrace();
			msg = "글작성 실패";
		} finally {
			DBCPUtil.close(pstmt, conn);
		}
		return msg;
	}

}
