package repository;

import java.util.List;
import java.util.Optional;

import util.PageMaker;
import vo.BoardVO;

public interface PostRepository {
	
	public List<BoardVO> tempFindAll();
	
	 public Optional<BoardVO> findByNum(int num);
	
	 public String update(BoardVO beforePost, BoardVO afterPost);
	 
	 public int countRow();
	 
	 public String delete(BoardVO vo);
	 
	 public List<BoardVO> sortedFindAll(PageMaker pm);
	 
	 public String insert(BoardVO vo);
}
