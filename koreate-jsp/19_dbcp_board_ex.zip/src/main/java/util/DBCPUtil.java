package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBCPUtil {
	
	public static Connection getConnection() {
		Connection conn = null;
		
		String driver = "com.mysql.cj.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/bigdata";
		String username = "bigdata";
		String password = "12345";
		
		try{
			Class.forName(driver);
			conn = DriverManager.getConnection(
				url,username,password
			);
			System.out.println("커넥션 연결 완료");
		}catch(ClassNotFoundException e){
			System.out.println("Dirver class를 찾을 수 없습니다.");
		}catch(SQLException e){
			System.out.println("연결 요청 정보 오류 :"+e.getMessage());
		}
		
		return conn;
	}
	
	public static void close(AutoCloseable... closer) {
		for(AutoCloseable c : closer) {
			try {
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}








