package util;

import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class origin_DBCPUtil {
	
	public static Connection getConnection() {
		Connection conn = null;		
		DataSource ds = null;
		
		try {
			/* Class.forName("com.mysql.cj.jdbc.Driver");
			 * DataSource에서 이미 호출 될 듯
			 */
			
			Context ctx = new InitialContext();
			ds = (DataSource)ctx
					.lookup("java:comp/env/jdbc/DBCP");
			
			conn = ds.getConnection();
		} catch (NamingException e) {
			e.printStackTrace();
			System.out.println("lookup 실패");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("뭔가 잘aht됨");
		}
		return conn;
	}
	
	public static void close(AutoCloseable... closer) {
		for(AutoCloseable c : closer) {
			try {
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}








