package service;

import java.util.List;
import java.util.Optional;

import repository.PostRepository;
import util.PageMaker;
import vo.BoardVO;

public class PostServiceImpl implements PostService{

	PostRepository pr;
	
	public PostServiceImpl(PostRepository pr) {
		this.pr = pr;
	}

	@Override
	public Optional<BoardVO> searchPost(int num) {
		return pr.findByNum(num);
	}

	@Override
	public String edit(BoardVO beforePost, BoardVO afterPost) {
		return pr.update(beforePost, afterPost);
	}

	@Override
	public int getCountRow() {
		return pr.countRow();
	}

	@Override
	public String delete(BoardVO vo) {
		return pr.delete(vo);
	}

	@Override
	public List<BoardVO> getPostAll(PageMaker pm) {
		return pr.sortedFindAll(pm);
	}

	@Override
	public String write(BoardVO vo) {
		return pr.insert(vo);
	}

	@Override
	public List<BoardVO> temp() {
		return pr.tempFindAll();
	}

	
	
}
