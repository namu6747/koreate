package service;

import java.util.List;
import java.util.Optional;

import util.PageMaker;
import vo.BoardVO;

public interface PostService {
	 public Optional<BoardVO> searchPost(int num);
		
	 public String edit(BoardVO beforePost, BoardVO afterPost);
	 
	 public int getCountRow();
	 
	 public String delete(BoardVO vo);
	 
	 public List<BoardVO> getPostAll(PageMaker pm);
	 
	 public String write(BoardVO vo);
	 
	 public List<BoardVO> temp();
}
